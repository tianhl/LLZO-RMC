cp GudrunN_mac.syspar GudrunGUI.sysparN
java -Duser.language=en -cp "./GudrunGUI" -jar "./GudrunGUI/GudrunGUI_4.jar" N
cp GudrunGUI.sysparN GudrunN_mac.syspar

