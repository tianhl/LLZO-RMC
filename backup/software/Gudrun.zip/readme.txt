To run GudrunGUI_4 (the current version):

1) Unpack the Gudrun.zip file in a suitable location. This should create a Gudrun folder in that location.

2) For Windows, open a command prompt and change to the Gudrun4 folder. Then:-

	a) For neutrons type 'GudrunN'

	b) For x-rays type 'GudrunX'

3) For Linux and other operating systems (e.g. Apple Mac), you will also need to download and unpack the auxilliary file 'Gudrunfiles.zip'. This will create a folder called 'Gudrunfiles'. Using the instructions contained in the readme.txt file in that folder, create the binaries. Then:-

	a) For neutrons type 'sh gudrunn.sh'.

	b) For x-rays type 'sh gudrunx.sh'.

4) The GUI should start as expected. One example input for each of neutrons and x-rays is provided in the run folder. To run these you will need to download the RawData.zip file from the same place as where the Gudrun.zip file was downloaded. When you attempt to run the examples, make sure the Instrument tab points to the correct location of the relevant Raw Data.
