cp GudrunX_mac.syspar GudrunGUI.sysparX
java -Duser.language=en -cp "./GudrunGUI" -jar "./GudrunGUI/GudrunGUI_4.jar" X
cp GudrunGUI.sysparX GudrunX_mac.syspar

