cp GudrunN_linux.syspar GudrunGUI.sysparN
java -Xmx1g -Duser.language=en -cp "./GudrunGUI" -jar "./GudrunGUI/GudrunGUI_4.jar" N
#java -Xmx1g -Duser.language=en -cp "/home/aks45/NetBeansProjects/GudrunGUI_4/dist" -jar "/home/aks45/NetBeansProjects/GudrunGUI_4/dist/GudrunGUI_4.jar" N
cp GudrunGUI.sysparN GudrunN_linux.syspar

