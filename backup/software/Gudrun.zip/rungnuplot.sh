gnome-terminal -e gnuplot
