gnome-terminal -e 'gnuplot GNUplot.plt -'
